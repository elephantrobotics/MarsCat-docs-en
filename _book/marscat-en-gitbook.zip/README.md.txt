1. Introduction
===============

Type: Service Robot

MarsCat-1001

This Gitbook is provided to help you when you have issues or questions
in the course of your life with MarsCat.

This Gitbook is not updated regularly. The updated time and content will
be on the table.

  -------------------------------------------------------------------------------------
  Version   Date(Chinese   Content
            time)          
  --------- -------------- ------------------------------------------------------------
  1         2021.6.9       Update some details, add App introduction etc.

  2         2021.6.17      Update how to turn on MarsCat, there are some precautions.
                           Update MarsApp(download and solutions for unable to
                           connect). Update FAQ

  3         2021.6.22      Update 10-MarsCatAPI

  4         2022.1.11      Update bttery data changes

  5         2022.2.6       Add how to update/recover MarsCat
  -------------------------------------------------------------------------------------

Users can download the latest version from the official website of Elephant Robotics at any time.
Link：[MarsCat-- Elephant
Robotics](https://www.elephantrobotics.com/marscat/)
